class <%= model_class_name %> < ActiveRecord::Base
end
